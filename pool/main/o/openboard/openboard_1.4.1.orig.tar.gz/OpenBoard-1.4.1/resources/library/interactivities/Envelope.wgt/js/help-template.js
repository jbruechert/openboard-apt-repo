<h3>Envelope</h3>
<h4>Representation of the number</h4>

<p>Drag and drop the paperclips one by one into the envelope. Simply click on the envelope to make reappear the paperclips on the page. They appear in a different color.</p>
<p>"Reload" button resets the exercises.</p>

<p>Enter the "Edit" mode to :</p>
<ul>
<li>choose the theme of the App : pad, slate, or none (by default pad),</li>
<li>change the number of paperclip(s).</li>
</ul>

<p>"Display" button comes back to the activity.</p>