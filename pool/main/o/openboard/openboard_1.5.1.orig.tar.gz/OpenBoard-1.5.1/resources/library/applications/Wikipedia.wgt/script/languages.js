﻿var sankoreLang = {
    "en":{
        "wikipedia": "Wikipedia",
        "prev_word":"Previous word",
        "next_word":"Next word",
        "search":"Search"
    },
    "ru":{
        "wikipedia": "Википедия",
        "prev_word":"Пред. слово",
        "next_word":"След. слово",
        "search":"Поиск"
    },
    "fr":{
        "wikipedia": "Wikipedia",
        "prev_word":"Mot précédent",
        "next_word":"Mot suivant",
        "search":"Rechercher"
    },
    "sk":{
        "wikipedia": "Wikipédia",
        "prev_word":"Predošlé slovo",
        "next_word":"Ďalšie slovo",
        "search":"Vyhľadať"
    }

};
