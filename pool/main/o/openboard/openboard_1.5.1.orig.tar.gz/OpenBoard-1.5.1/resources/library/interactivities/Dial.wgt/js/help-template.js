<h3>Dial</h3>
<h4>Mental calculation</h4>

<p> With this interactivity you can work a particular number (number of the days) with additions, subtractions, multiplications and divisions. The goal is to train mental calculation clicking on the dial and on the question mark. </p>

<p> "Reload" button resets the selection. </p>
<p> Enter the "Edit" mode to : </p>
<ul> <li> choose the theme of the App : pad, slate, or none (by default : pad), </li>
<li> modify the number in the center of the dial. </li> </ul>

<p> To change the number in the center, click and replace it.</p>

<p>"Display" button comes back to the activity.</p>

