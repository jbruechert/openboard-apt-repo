﻿<h3>Ciferník</h3>
<h4>Počítanie spamäti</h4>

<p>V tejto interaktívnej aktivite treba zistiť neznáme číslo (počet dní) sčítaním, odčítaním, násobením alebo delením
čísel na ciferníku. Jej cieľom je precvičiť počítanie spamäti. Kliknite na číslo a&nbsp;znamienko na ciferníku. 
Po kliknutí na otáznik sa zobrazí výsledok (neznáme číslo, čiže počet dní).</p>
<p>Výber čísla a znamienka zrušíte tlačidlom „Obnoviť“. </p>

<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav zmeniť:</p>
<ul><li>farebný motív na tablet, bridlicu alebo na žiadny (predvolený je tablet),</li>
<li>číslo v strede ciferníka.</li></ul>

<p>Ak chcete zmeniť číslo v strede ciferníka, kliknite naň a prepíšte ho.</p>

<p>Tlačidlom „Zobraziť“ sa z režimu úprav vrátite na aktivitu.</p>

