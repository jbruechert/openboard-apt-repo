<h3>Enveloppe</h3>
<h4>Représentation du nombre.</h4>

<p>Glisser les trombones un à un dans l’enveloppe. Il suffit de cliquer sur l’enveloppe pour faire réapparaître les trombones sur la page. Ces derniers apparaissent dans une autre couleur. </p>

<p>Le bouton "Recharger" replace tous les trombones sur la page.</p>

<p>Le bouton “Modifier” vous permet : </p>
<ul>
<li>de choisir le thème de l’interactivité : tablette, ardoise ou aucun (par défaut tablette), </li>
<li>de déterminer le nombre de trombone(s) souhaité(s).</li> 
</ul>

<p>Le bouton “Afficher” vous permet d’utiliser l’activité.</p>